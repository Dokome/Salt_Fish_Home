var a="/assets/default-avatar.b7d77977.png";export{a as d};
