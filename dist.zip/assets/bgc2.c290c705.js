var s="/assets/bgc2.81249e0d.jpg";export{s as b};
